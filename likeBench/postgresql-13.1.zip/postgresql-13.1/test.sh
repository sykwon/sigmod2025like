


cp -R /home/silvan/code/postgresql-14.5-selectivity-injection /home/silvan/dbs/si-pg14.5
/home/silvan/dbs/si-pg14.5/configure --prefix=/home/silvan/dbs/si-pg14.5
make install /home/silvan/dbs/si-pg14.5
/home/silvan/dbs/si-pg14.5/bin/initdb -D /home/silvan/dbs/si-pg14.5/data
/home/silvan/dbs/si-pg14.5/bin/pg_ctl -D /home/silvan/dbs/si-pg14.5/data -l /home/silvan/dbs/si-pg14.5/bin/logfile start
/home/silvan/dbs/si-pg14.5/bin/createdb imdb-ceb
/home/silvan/dbs/si-pg14.5/bin/pg_restore -d imdb-ceb /home/silvan/data/202305_backups/imdb_ceb.backup
/home/silvan/dbs/si-pg14.5/bin/createdb imdb_schema
/home/silvan/dbs/si-pg14.5/bin/pg_restore -d imdb_schema /home/silvan/data/202305_backups/imdb_schema.backup
/home/silvan/dbs/si-pg14.5/bin/psql -d imdb_schema -c "CREATE ROLE postgres SUPERUSER; ALTER ROLE postgres WITH LOGIN; ALTER ROLE postgres WITH PASSWORD 'postgres'"


